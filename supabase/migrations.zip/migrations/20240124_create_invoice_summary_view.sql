CREATE OR REPLACE VIEW employer_invoice_summary AS
SELECT 
  e.id as employer_id,
  e.name as employer_name,
  COUNT(DISTINCT i.id) as total_invoices,
  COUNT(DISTINCT CASE WHEN i.status = 'paid' THEN i.id END) as paid_invoices,
  COUNT(DISTINCT CASE WHEN i.status = 'pending' THEN i.id END) as pending_invoices,
  COALESCE(SUM(i.total_amount), 0) as total_amount,
  COALESCE(SUM(CASE WHEN i.status = 'paid' THEN i.total_amount ELSE 0 END), 0) as paid_amount,
  COALESCE(SUM(CASE WHEN i.status = 'pending' THEN i.total_amount ELSE 0 END), 0) as pending_amount,
  MAX(i.created_at) as last_invoice_date
FROM employers e
LEFT JOIN invoices i ON e.id = i.employer_id;

GRANT SELECT ON employer_invoice_summary TO authenticated;
