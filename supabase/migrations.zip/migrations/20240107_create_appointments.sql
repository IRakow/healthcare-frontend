-- Create appointments table
CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reason TEXT,
  type TEXT CHECK (type IN ('telemed', 'in_person')) DEFAULT 'in_person',
  status TEXT CHECK (status IN ('pending', 'confirmed', 'in_progress', 'complete', 'cancelled')) DEFAULT 'pending',
  date DATE NOT NULL,
  time TEXT NOT NULL,
  video_url TEXT,
  transcript TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on appointments table
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Policy: Patients can view their own appointments
CREATE POLICY "Patients can view their appointments"
  ON appointments FOR SELECT
  USING (auth.uid() = patient_id);

-- Policy: Providers can view their appointments
CREATE POLICY "Providers can view their appointments"
  ON appointments FOR SELECT
  USING (auth.uid() = provider_id);
