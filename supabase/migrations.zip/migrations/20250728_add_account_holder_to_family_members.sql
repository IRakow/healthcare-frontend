-- Add account_holder_id field referencing auth.users(id)
ALTER TABLE family_members
ADD COLUMN account_holder_id UUID REFERENCES auth.users(id);

-- Optional: add index for faster lookup (recommended)
CREATE INDEX idx_family_members_account_holder_id ON family_members(account_holder_id);
