-- Create view for employer invoice summary
CREATE OR REPLACE VIEW employer_invoice_summary AS
SELECT 
  e.id AS employer_id,
  e.name AS employer_name,
  COUNT(DISTINCT i.id) AS total_invoices,
  COUNT(DISTINCT CASE WHEN i.status = 'paid' THEN i.id END) AS paid_invoices,
  COUNT(DISTINCT CASE WHEN i.status = 'pending' THEN i.id END) AS pending_invoices,
  COALESCE(SUM(i.total_amount), 0) AS total_amount,
  COALESCE(SUM(CASE WHEN i.status = 'paid' THEN i.total_amount ELSE 0 END), 0) AS paid_amount,
  COALESCE(SUM(CASE WHEN i.status = 'pending' THEN i.total_amount ELSE 0 END), 0) AS pending_amount,
  MAX(i.created_at) AS last_invoice_date
FROM employers e
LEFT JOIN invoices i ON e.id = i.employer_id;

-- Grant access to the view
GRANT SELECT ON employer_invoice_summary TO authenticated;
