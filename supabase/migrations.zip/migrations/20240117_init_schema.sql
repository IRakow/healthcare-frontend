-- Table: users (via auth.users)
-- You typically won't need to redefine this, Supabase manages it automatically.



-- Table: family_members
CREATE TABLE family_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_holder_id UUID REFERENCES auth.users(id),
  full_name TEXT NOT NULL,
  birthdate DATE,
  relation TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: appointments
CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES auth.users(id),
  date DATE NOT NULL,
  time TEXT NOT NULL,
  reason TEXT,
  status TEXT DEFAULT 'pending',
  type TEXT DEFAULT 'telemed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: patient_timeline_events
CREATE TABLE patient_timeline_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES auth.users(id),
  type TEXT NOT NULL,
  label TEXT NOT NULL,
  data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
