-- Now that appointments table exists, we can apply this:
CREATE POLICY "Providers can view employer info for their patients"
  ON employer_patients FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM appointments a
      WHERE a.provider_id = auth.uid()
      AND a.patient_id = employer_patients.patient_id
    )
  );
