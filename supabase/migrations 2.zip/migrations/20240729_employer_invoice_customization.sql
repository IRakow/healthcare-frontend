alter table employers
add column invoice_header text,
add column invoice_footer text;