-- Create employers table
CREATE TABLE employers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_email TEXT,
  phone TEXT,
  address TEXT,
  logo_url TEXT,
  branding JSONB DEFAULT '{}',
  settings JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  owner_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for employers
CREATE INDEX idx_employers_name ON employers(name);
CREATE INDEX idx_employers_is_active ON employers(is_active);
CREATE INDEX idx_employers_created_at ON employers(created_at DESC);

-- Create employer-patient relationship table
CREATE TABLE employer_patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employer_id UUID REFERENCES employers(id) ON DELETE CASCADE,
  patient_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  employee_id TEXT,
  department TEXT,
  start_date DATE NOT NULL,
  end_date DATE,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(employer_id, patient_id, end_date)
);

-- Indexes for employer_patients
CREATE INDEX idx_employer_patients_employer_id ON employer_patients(employer_id);
CREATE INDEX idx_employer_patients_patient_id ON employer_patients(patient_id);
CREATE INDEX idx_employer_patients_is_active ON employer_patients(is_active);
CREATE INDEX idx_employer_patients_dates ON employer_patients(start_date, end_date);

-- Enable RLS
ALTER TABLE employers ENABLE ROW LEVEL SECURITY;
ALTER TABLE employer_patients ENABLE ROW LEVEL SECURITY;

-- RLS Policies for employers
CREATE POLICY "Owners can manage all employers"
  ON employers FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'owner'
    )
  );

CREATE POLICY "Admins can view all employers"
  ON employers FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

-- RLS Policies for employer_patients
CREATE POLICY "Owners can manage all employer-patient relationships"
  ON employer_patients FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON ur.role_id = r.id
      WHERE ur.user_id = auth.uid() AND r.name = 'owner'
    )
  );

CREATE POLICY "Patients can view their own employer relationships"
  ON employer_patients FOR SELECT
  USING (auth.uid() = patient_id);


-- Triggers to update updated_at
CREATE TRIGGER update_employers_updated_at
  BEFORE UPDATE ON employers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employer_patients_updated_at
  BEFORE UPDATE ON employer_patients
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- View: Active employer-patient relationships
CREATE OR REPLACE VIEW active_employer_patients AS
SELECT 
  ep.*,
  e.name AS employer_name,
  e.logo_url AS employer_logo,
  e.branding AS employer_branding,
  p.raw_user_meta_data->>'name' AS patient_name,
  p.email AS patient_email
FROM employer_patients ep
JOIN employers e ON ep.employer_id = e.id
JOIN auth.users p ON ep.patient_id = p.id
WHERE ep.is_active = true
  AND e.is_active = true;

GRANT SELECT ON active_employer_patients TO authenticated;

-- Function: Get a patient's current employer
CREATE OR REPLACE FUNCTION get_patient_current_employer(p_patient_id UUID)
RETURNS TABLE(
  employer_id UUID,
  employer_name TEXT,
  start_date DATE,
  employee_id TEXT,
  department TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ep.employer_id,
    e.name AS employer_name,
    ep.start_date,
    ep.employee_id,
    ep.department
  FROM employer_patients ep
  JOIN employers e ON ep.employer_id = e.id
  WHERE ep.patient_id = p_patient_id
    AND ep.is_active = true
    AND e.is_active = true
  ORDER BY ep.start_date DESC
  LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ✅ Now that employers.owner_id exists, apply this policy safely:
CREATE POLICY "Employers can view their employees" ON users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM employers e
      WHERE e.owner_id = auth.uid()
      AND e.id = users.employer_id
    )
  );

-- (Optional sample data - commented out)
-- INSERT INTO employers (name, contact_email) VALUES
--   ('Acme Corporation', 'hr@acme.com'),
--   ('Tech Innovators LLC', 'benefits@techinnovators.com'),
--   ('Healthcare Partners', 'admin@healthcarepartners.com');
--
-- INSERT INTO employer_patients (employer_id, patient_id, start_date) VALUES
--   ((SELECT id FROM employers WHERE name = 'Acme Corporation'), 'patient-uuid-1', '2024-01-01'),
--   ((SELECT id FROM employers WHERE name = 'Tech Innovators LLC'), 'patient-uuid-2', '2023-06-15');
