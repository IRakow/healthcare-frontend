-- 20240121_add_user_employer_fk.sql

-- Add the foreign key constraint after employers table exists
ALTER TABLE users
ADD CONSTRAINT fk_users_employer
FOREIGN KEY (employer_id)
REFERENCES employers(id)
ON DELETE SET NULL;
